package com.example.dhananjay.advanced;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.FirebaseError;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
public class FinalActivity extends AppCompatActivity {
    Button button,allusers;
    public  String st12;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final);
        FirebaseDatabase mFirebaseDatabase = FirebaseDatabase.getInstance();
        final DatabaseReference databaseReference =    mFirebaseDatabase.getReference().child("users");
        FirebaseAuth firebaseUser=FirebaseAuth.getInstance();

        button=(Button)findViewById(R.id.button);
        allusers=(Button)findViewById(R.id.all_user);
        allusers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(FinalActivity.this,ShowImagesActivity.class);
                startActivity(i);
            }
        });
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(final DataSnapshot dataSnapshot) {
                int i=0;
                LinearLayout ll = (LinearLayout)findViewById(R.id.layout);
                //              ll.canScrollHorizontally(10);
                ll.canScrollVertically(10);
                FirebaseAuth firebaseUser=FirebaseAuth.getInstance();
                FirebaseUser user=firebaseUser.getCurrentUser();
                for (final DataSnapshot childDataSnapshot : dataSnapshot.getChildren()) {
 //                   Toast.makeText(FinalActivity.this,user.getUid(), Toast.LENGTH_SHORT).show();
                   //Toast.makeText(FinalActivity.this, childDataSnapshot.getKey(), Toast.LENGTH_SHORT).show();
                    if(user.getUid().equals(childDataSnapshot.getKey())){
                        st12=childDataSnapshot.getValue().toString();
                    }
                    Button btn = new Button(FinalActivity.this);
                    btn.setId(i);
                    final String st=childDataSnapshot.getValue().toString();
                    int id_ = btn.getId();
                    btn.setText(st);
                    btn.setBackgroundColor(Color.rgb(70, 80, 190));
                    btn.setHeight(40);
                    btn.setWidth(20);
                    ll.addView(btn);
                    Button btn1 = ((Button) findViewById(id_));
                    btn1.setOnClickListener(new View.OnClickListener() {
                        public void onClick(View view) {
                            Intent myIntent = new Intent(FinalActivity.this, MessageActivity.class);
                            myIntent.putExtra("uid",childDataSnapshot.getKey());
                            myIntent.putExtra("name",childDataSnapshot.getValue().toString());
                            myIntent.putExtra("current_user",st12);
                            startActivity(myIntent);
                        }
                    });
                    i=i+1;
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                Toast.makeText(FinalActivity.this, "Error", Toast.LENGTH_SHORT).show();
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth auth=FirebaseAuth.getInstance();
                auth.signOut();
                Intent i=new Intent(FinalActivity.this,MainActivity.class);
                startActivity(i);
            }
        });
    }
}