package com.example.dhananjay.advanced;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class Higher_Authority extends AppCompatActivity {
    EditText name,email,password,password1,id,state,city;
    Button signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_higher__authority);
        name=(EditText)findViewById(R.id.input_name);
        email=(EditText)findViewById(R.id.input_email);
        password=(EditText)findViewById(R.id.input_password);
        password1=(EditText)findViewById(R.id.input_password_repeat);
        id=(EditText)findViewById(R.id.input_password_id);
        state=(EditText)findViewById(R.id.state);
        city=(EditText)findViewById(R.id.distric);
        signup=(Button)findViewById(R.id.btn_signup);
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth firebaseAuth=FirebaseAuth.getInstance();
                DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference().child(state.getText().toString()).child(city.getText().toString());
                if(password.getText().toString().equals(password1.getText().toString())) {
                    HashMap<String, String> hm = new HashMap<String, String>();
                    hm.put("name", name.getText().toString());
                    hm.put("email", email.getText().toString());
                    hm.put("password", password.getText().toString());
                    hm.put("id",id.getText().toString());
                    databaseReference.setValue(hm);
                        firebaseAuth.createUserWithEmailAndPassword(email.getText().toString(), password.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(Higher_Authority.this, "Successfully Created Account", Toast.LENGTH_SHORT).show();
                                    Intent i =new Intent(Higher_Authority.this,ShowImagesActivity.class);
                                    startActivity(i);
                                }
                                else
                                {
                                    Toast.makeText(Higher_Authority.this, "Error", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }

            }
        });
    }
}
