package com.example.dhananjay.advanced;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
public class MessageActivity extends AppCompatActivity {
    FirebaseAuth mAuth;
    EditText editText;
    Button b,groupchat;
    //LinearLayout ll;
    TextView textView;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR1)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);
        Intent myIntent = getIntent(); // gets the previously created intent
        String uid = myIntent.getStringExtra("uid"); // will return "FirstKeyValue"
        String name= myIntent.getStringExtra("name");
        final String current_user=myIntent.getStringExtra("current_user");
      //  ll=(LinearLayout)findViewById(R.id.ll);
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user=mAuth.getCurrentUser();
        editText=(EditText)findViewById(R.id.editText2);
        b=(Button)findViewById(R.id.button2);
        groupchat=(Button)findViewById(R.id.groupchat);
        textView=(TextView)findViewById(R.id.textView2);
        //textView3=(TextView)findViewById(R.id.textView3);
        textView.setMovementMethod(new ScrollingMovementMethod());
        FirebaseDatabase db=FirebaseDatabase.getInstance();
        char c=user.getUid().charAt(0);
        char d=uid.charAt(0);
        String point="";
        if(c>d) {
            point=user.getUid()+uid;
        }
        else
        {
            point=uid+user.getUid();
        }
        DatabaseReference ref = db.getReference().child("Message").child(point);
        ref.addValueEventListener(new ValueEventListener() {
            String sr;
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    String temp="";
                for(final DataSnapshot childDataSnapshot : dataSnapshot.getChildren()){
                    ///textView.setText(childDataSnapshot.getKey());
                  //  textView.setText(childDataSnapshot.getValue().toString());
                    temp=childDataSnapshot.getValue().toString();
                    sr=sr+"\n"+temp.substring(1,temp.length()-1);
                }
                textView.setText(sr);
                sr="";
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent myIntent = getIntent(); // gets the previously created intent
                String uid = myIntent.getStringExtra("uid"); // will return "FirstKeyValue"
                String name= myIntent.getStringExtra("name");
                String current_user=myIntent.getStringExtra("current_user");
                Date c = Calendar.getInstance().getTime();
                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
                mAuth = FirebaseAuth.getInstance();
                FirebaseUser user=mAuth.getCurrentUser();
                FirebaseDatabase database=FirebaseDatabase.getInstance();
                char a,b;
                a=user.getUid().charAt(0);
                b=uid.charAt(0);
                if(a>b) {
                    DatabaseReference mRef = database.getReference().child("Message").child(user.getUid() + uid).child(c.toString());
                    HashMap<String, String> hm = new HashMap<String, String>();
                    hm.put(current_user + " -> " + name, editText.getText().toString());
                    mRef.setValue(hm);
                }
                else{
                    DatabaseReference mRef = database.getReference().child("Message").child(uid+user.getUid()).child(c.toString());
                    HashMap<String, String> hm = new HashMap<String, String>();
                    hm.put(current_user + " -> " + name, editText.getText().toString());
                    mRef.setValue(hm);
                }
                textView.setMovementMethod(new ScrollingMovementMethod());
                editText.setText("");

            }
        });
      /* DatabaseReference ref1 =db.getReference().child(user.getUid());
       ref1.addValueEventListener(new ValueEventListener() {
           @Override
           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               for(final DataSnapshot childDataSnapshot : dataSnapshot.getChildren()){
                   textView3.append(childDataSnapshot.getKey()+":\t"+childDataSnapshot.getValue()+"\n");
               }
           }

           @Override
           public void onCancelled(@NonNull DatabaseError databaseError) {

           }
       });
       */
    groupchat.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Intent i=new Intent(MessageActivity.this,GroupChatActivity.class);
            i.putExtra("name",current_user);
            startActivity(i);
        }
    });
    }
}
