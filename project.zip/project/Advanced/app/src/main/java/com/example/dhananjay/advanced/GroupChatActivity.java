package com.example.dhananjay.advanced;
import android.content.Intent;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
public class GroupChatActivity extends AppCompatActivity {
    TextView textView;
    Button b;
    public String st="";
    public  int len=0;
    EditText editText;
    public List a = new ArrayList();
    int pharji=0;
    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_chat);
        textView=(TextView)findViewById(R.id.textView4);
        textView.setMovementMethod(new ScrollingMovementMethod());
        b=(Button)findViewById(R.id.button3);
        editText=(EditText)findViewById(R.id.editText7);
        final FirebaseDatabase database=FirebaseDatabase.getInstance();
        final DatabaseReference dbRef=database.getReference().child("Group-Chat");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                // LinearLayout ll=(LinearLayout)findViewById(R.id.layout1);
                String sr="";
                Intent myIntent = getIntent(); // gets the previously created intent
                String name = myIntent.getStringExtra("name");
                textView.setMovementMethod(new ScrollingMovementMethod());
                for(final  DataSnapshot childDataSnapshot : dataSnapshot.getChildren()){
                    String nam="";
                    String message="",full="";
                    full=childDataSnapshot.getValue().toString();
                    int k=0;
                    for(k=1;k<full.length();k++){
                        if(full.charAt(k)=='='){
                            break;
                        }
                        else{
                            nam=nam+full.charAt(k);
                        }
                    }
                    for(int l=k+1;l<full.length()-1;l++){
                        message=message+full.charAt(l);
                    }
                    //Toast.makeText(GroupChatActivity.this, nam+" "+name, Toast.LENGTH_SHORT).show();
                    if(nam.equals(name)) {
                        sr = sr + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"+childDataSnapshot.getKey().substring(childDataSnapshot.getKey().length()-8,childDataSnapshot.getKey().length())+"\n";
                        sr = sr + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"+message+"\n";
                        //a.add("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t"+message+"\n");
                    }
                    else{
                        sr = sr + "\t"+childDataSnapshot.getKey().substring(childDataSnapshot.getKey().length()-8,childDataSnapshot.getKey().length())+"\n";
                        sr = sr  + "\t"+childDataSnapshot.getValue().toString().substring(1, childDataSnapshot.getValue().toString().length() - 1) + "\n";
                        //a.add("\t"+childDataSnapshot.getValue().toString().substring(1, childDataSnapshot.getValue().toString().length() - 1) + "\n");
                    }
                }
                textView.setText(sr);
                sr="";
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Date C = Calendar.getInstance().getTime();
                String c1=C.toString();
                int len=c1.length();
                String year=c1.substring(len-4,len);
                String month=c1.substring(4,7);
                String date=c1.substring(8,10);
                String time=c1.substring(11,19);
                int mon;
                if(date.equals("Jan")){
                    mon=1;
                }
                else if(date.equals("Feb")){
                    mon=2;
                }
                else if(date.equals("Feb")){
                    mon=2;
                }
                else if(date.equals("Mar")){
                    mon=3;
                }
                else if(date.equals("Apr")){
                    mon=4;
                }
                else if(date.equals("May")){
                    mon=5;
                }
                else if(date.equals("Jun")){
                    mon=6;
                }else if(date.equals("Jul")){
                    mon=7;
                }else if(date.equals("Aug")){
                    mon=8;
                }else if(date.equals("Sep")){
                    mon=9;

                }
                else if(date.equals("Oct")){
                    mon=10;
                }
                else if(date.equals("Nov")){
                    mon=11;
                }
                else{
                    mon=12;
                }




                String c=year+" "+String.valueOf(mon)+" "+date+" "+time;
                FirebaseAuth mAuth;
                FirebaseDatabase database1=FirebaseDatabase.getInstance();
                mAuth = FirebaseAuth.getInstance();
                FirebaseUser user=mAuth.getCurrentUser();
                DatabaseReference dbref=database1.getReference().child(user.getUid());
                dbRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        st=dataSnapshot.getValue().toString();
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                    }
                });
                textView.setMovementMethod(new ScrollingMovementMethod());
                Intent myIntent = getIntent(); // gets the previously created intent
                String name = myIntent.getStringExtra("name");
                DatabaseReference dbref1=database1.getReference().child("Group-Chat").child(c.toString());
                HashMap<String,String> hm=new HashMap<String, String>();
                hm.put(name,editText.getText().toString());
                dbref1.setValue(hm);
                editText.setText("");
            }
        });
    }
}