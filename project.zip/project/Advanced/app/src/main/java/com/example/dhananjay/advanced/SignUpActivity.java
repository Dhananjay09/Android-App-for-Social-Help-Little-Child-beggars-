package com.example.dhananjay.advanced;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
public class SignUpActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;
    Button b;
    EditText t1,t2,email1,password1,password2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        t1=(EditText)findViewById(R.id.first_name);
        b=(Button)findViewById(R.id.sub);
        t2=(EditText)findViewById(R.id.last_name);
        email1=(EditText)findViewById(R.id.email);
        password1=(EditText)findViewById(R.id.password1);
        password2=(EditText)findViewById(R.id.password2);
        mAuth = FirebaseAuth.getInstance();
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=email1.getText().toString();
                final String password=password1.getText().toString();
                String check_password=password2.getText().toString();
                final String first_name=t1.getText().toString();
                final String last_name=t2.getText().toString();
                if(email.isEmpty())
                {
                    Toast.makeText(SignUpActivity.this, "Please Enter The Email", Toast.LENGTH_SHORT).show();
                }
                else if(password.isEmpty())
                {
                    Toast.makeText(SignUpActivity.this, "Please Enter the password", Toast.LENGTH_SHORT).show();
                }
                else if(check_password.isEmpty())
                {
                    Toast.makeText(SignUpActivity.this, "Please Repeat thepassword", Toast.LENGTH_SHORT).show();
                }
                else if (first_name.isEmpty()){
                    Toast.makeText(SignUpActivity.this, "Please Enter the First Name", Toast.LENGTH_SHORT).show();
                }
                else if(last_name.isEmpty()){
                    Toast.makeText(SignUpActivity.this, "Plese Enter the last name", Toast.LENGTH_SHORT).show();
                }
                else {
                    if (password.equals(check_password)) {
                        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    FirebaseDatabase database = FirebaseDatabase.getInstance();
                                    DatabaseReference myRef = database.getReference("users").child(user.getUid());
                                    myRef.setValue(first_name);
                                    DatabaseReference myRef1 = database.getReference(user.getUid());
                                    HashMap<String,String> hm=new HashMap<String,String>();
                                    hm.put("uid",first_name);
                                    hm.put("last_name",last_name);
                                    hm.put("password",password);
                                    myRef1.setValue(hm);
                                    Toast.makeText(SignUpActivity.this, "Successfully Done", Toast.LENGTH_SHORT).show();
                                    Intent i=new Intent(SignUpActivity.this,FinalActivity.class);
                                    startActivity(i);
                                }
                                else
                                {
                                    Toast.makeText(SignUpActivity.this, "Error", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                else {
                    Toast.makeText(SignUpActivity.this, "Password not matched", Toast.LENGTH_SHORT).show();
                }
            }}
        });
    }

}