package com.example.dhananjay.advanced;
import android.annotation.TargetApi;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class FileActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int PICK_IMAGE_REQUEST = 1;
    FloatingActionButton floatingActionButton;
    private static final String TAG = "MainActivity";
    EditText editText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file);
        findViewById(R.id.btnSelectImage).setOnClickListener(this);
        DatabaseReference dbref=FirebaseDatabase.getInstance().getReference().child("files");
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i=0;
                String st="";
                for(final DataSnapshot childDataSnapshot : dataSnapshot.getChildren()){
                    st = childDataSnapshot.getValue().toString();
                    //Toast.makeText(FileActivity.this, childDataSnapshot.getValue().toString(), Toast.LENGTH_SHORT).show();
                    i=i+1;
                    showimage(st);

                    //   showimage(childDataSnapshot.getValue().toString());
            //        Toast.makeText(FileActivity.this, childDataSnapshot.getValue().toString(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
      //  Toast.makeText(this, "Dhananjay  "+ i +"   Dj", Toast.LENGTH_SHORT).show();
//        editText=(EditText)findViewById(R.id.edittext);
        //showimage();
    }



    /* Choose an image from Gallery */
    @RequiresApi(api = Build.VERSION_CODES.O)
    void openImageChooser() {
        Intent intent = new Intent();
// Show only images, no videos or anything else
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
// Always show the chooser (if there are multiple options available)
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }
    @RequiresApi(api = Build.VERSION_CODES.O)
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
       // Toast.makeText(this, "Dhananjay", Toast.LENGTH_SHORT).show();
        if (resultCode == RESULT_OK) {
            if (requestCode == PICK_IMAGE_REQUEST) {
                // Get the url from data
                Uri selectedImageUri = data.getData();
                Toast.makeText(this, selectedImageUri.toString(), Toast.LENGTH_SHORT).show();
                if (null != selectedImageUri) {
                    String path = selectedImageUri.toString();
                    DatabaseReference reference=FirebaseDatabase.getInstance().getReference().child("FileActivity");
                    reference.setValue(path);
                    StorageReference mStorageRef;
                    mStorageRef = FirebaseStorage.getInstance().getReference();
                    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
                    LocalDateTime now = LocalDateTime.now();
                    Toast.makeText(this, "Dhananjay", Toast.LENGTH_SHORT).show();
                    DatabaseReference databaseReference=FirebaseDatabase.getInstance().getReference("file").child(now.toString());
                    databaseReference.setValue(now);
                    StorageReference riversRef = mStorageRef.child("images/"+now+".jpg");
                    riversRef.putFile(Uri.parse(path))
                            .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                                    // Get a URL to the uploaded content
                                    //  Uri downloadUrl = taskSnapshot.getDownloadUrl();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception exception) {
                                    // Handle unsuccessful uploads
                                    // ...
                                }
                            });
                    //  Toast.makeText(this, selectedImageUri.toString(), Toast.LENGTH_SHORT).show();
                    //((ImageView) findViewById(R.id.imgView)).setImageURI(selectedImageUri);
                }

            }
        }
    }
    /* Get the real path from the URI */
    public String getPathFromURI(Uri contentUri) {
        String res = null;
        String[] proj = {MediaStore.Images.Media.DATA};
        Cursor cursor = getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor.moveToFirst()) {
            int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
            res = cursor.getString(column_index);
        }
        cursor.close();
        return res;
    }
    @TargetApi(Build.VERSION_CODES.O)
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onClick(View v) {
        openImageChooser();
    }

    public void showimage(String st){
        int i=0;
        final LinearLayout ll = (LinearLayout) findViewById(R.id.idf);
        //Toast.makeText(this, st, Toast.LENGTH_SHORT).show();
        /*Toast.makeText(this, st, Toast.LENGTH_SHORT).show();
        final String[] parts = st.split("jpg");
        for(String w:parts) {
            int i=0;
            w = "uploads/" + w + "jpg";
            Toast.makeText(this, w, Toast.LENGTH_SHORT).show();
            */
                try {
                    //Toast.makeText(this, parts[i].toString(), Toast.LENGTH_SHORT).show();
                    //Toast.makeText(FileActivity.this, list.get(i).toString(), Toast.LENGTH_SHORT).show();
                    final java.io.File localFile = java.io.File.createTempFile("images", "jpg");
                    StorageReference mStorageRef;
                    mStorageRef = FirebaseStorage.getInstance().getReference();
                    StorageReference riversRef = mStorageRef.child(st);
                    //      Toast.makeText(this, st1 , Toast.LENGTH_SHORT).show();
                    //Toast.makeText(this, riversRef.getDownloadUrl().toString(), Toast.LENGTH_SHORT).show();
                     int finalI = i+1;
                    riversRef.getFile(localFile)
                            .addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                                @Override

                                public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                                    // Toast.makeText(FileActivity.this, (CharSequence) localFile, Toast.LENGTH_SHORT).show();
                                    //
                                    //
                                    //                       for(final FileDownloadTask.TaskSnapshot childDataSnapshot : taskSnapshot){}
                                    ImageView im = new ImageView(FileActivity.this);
                                    Toast.makeText(FileActivity.this, "Inside", Toast.LENGTH_SHORT).show();
                                    im.setId('f');
                                    int id1 = im.getId();
                                    im.setImageURI(Uri.fromFile(localFile));
//                            ((ImageView) findViewById(R.id.id1)).setImageURI(Uri.fromFile(localFile));
                                    ll.addView(im);
                                    TextView btn = new Button(FileActivity.this);
                                    btn.setId('d');
                                    int id_ = btn.getId();
                                    //btn.setText(parts[finalI]+"jpeg");
                                    btn.setBackgroundColor(Color.rgb(70, 80, 190));
                                    btn.setHeight(40);
                                    btn.setWidth(20);
                                    ll.addView(btn);
                                    ImageView im1 = new ImageView(FileActivity.this);
                                    im.setId('g');
                                    int id2 = im.getId();
                                    im1.setImageURI(Uri.fromFile(localFile));
//                            ((ImageView) findViewById(R.id.id1)).setImageURI(Uri.fromFile(localFile));
                                    ll.addView(im1);
                                }
                            }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            // Handle failed download
                            // ...
                            Toast.makeText(FileActivity.this, "Failed to get", Toast.LENGTH_SHORT).show();
                        }


                    });
                } catch (IOException e) {
                    e.printStackTrace();
                }



    }
}